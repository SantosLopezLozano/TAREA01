package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)


            with(binding){
                idBtnPassData.setOnClickListener {
                    if (idEdtMsg.text.toString().isNullOrEmpty()){
                        val snackbar = Snackbar
                            .make(it, "このエントリは空です", Snackbar.LENGTH_LONG)
                        snackbar.show()

                    } else {
                        val msg = idEdtMsg.text.toString()
                        val i = Intent(this@MainActivity, SecondActivity::class.java)
                        i.putExtra("nombre", msg)
                        startActivity(i)
                    }

                }
            }

        }
    }
